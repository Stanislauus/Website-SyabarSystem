/*document.addEventListener('DOMContentLoaded', function() {
    // Создаем ResizeObserver для отслеживания изменений размера.columns
    const resizeObserver = new ResizeObserver(entries => {
        for (let entry of entries) {
            const { width } = entry.contentRect;
            if (width <= 768) {
                // Логика для переключения блоков при ширине меньше или равной 768px
                if (!hasSwitched) {
                    handleColumnSwitch();
                    hasSwitched = true; // Предотвращаем повторное переключение при каждом изменении размера
                }
            }
        }
    });

    // Начинаем наблюдение за.columns
    resizeObserver.observe(document.querySelector('.columns'));

    // Флаг для отслеживания, было ли уже переключение
    let hasSwitched = false;

    // Функция для переключения блоков
    function handleColumnSwitch() {
        const columnsContainer = document.querySelector('.columns');
        const columnGroups = document.querySelectorAll('.column');

        // Скрываем все группы блоков
        columnGroups.forEach(group => {
            group.style.display = 'none';
        });

        // Показываем первую группу блоков
        columnGroups[0].style.display = 'block';

        // Используем requestAnimationFrame для оптимизации обновлений
        function updateColumns(timestamp) {
            // Скрываем текущую группу
            columnGroups[0].style.display = 'none';

            // Переходим к следующей группе
            const nextGroupIndex = (columnGroups.length + 1) % columnGroups.length;
            columnGroups[nextGroupIndex].style.display = 'block';

            // Устанавливаем таймер для следующего переключения через 5 секунд
            setTimeout(function() {
                requestAnimationFrame(updateColumns);
            }, 5000);
        }

        // Запускаем первый кадр обновления
        requestAnimationFrame(updateColumns);
    }
});
*/